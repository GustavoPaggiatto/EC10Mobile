import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { AppBar } from '@react-native-material/core';
import HomeComponent from './Home';
import CategoriaComponent from './Categoria';
import { createDatabase } from './services/dbCreator';

var Stack = createNativeStackNavigator();
createDatabase();

export default function App() {  
  return (
    <NavigationContainer>
      <AppBar title="Pizzaria do Gordola"/>
      <Stack.Navigator 
      initialRouteName="Home"
      screenOptions={{ headerStyle: { backgroundColor: "#f4f4f4" } }}>
        <Stack.Screen name="Home" component={HomeComponent}/>
        <Stack.Screen name="Categoria" component={CategoriaComponent} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
