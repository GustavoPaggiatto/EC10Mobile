import { Button, Stack } from '@react-native-material/core';

export default function HomeComponent({ navigation }) {
    return (
        <Stack fill center spacing={10}>                
            <Button title="Categorias" style={{width: 150}} onPress={() => navigation.navigate("Categoria")} />
            <Button title="Produtos" style={{width: 150}} />
            <Button title="Comprar" style={{width: 150}} />
            <Button title="Vendas" style={{width: 150}} />
        </Stack>
    );
}