import { dbConnection } from './db';

const db=dbConnection.getConnection();

export default function GetCategorias() {
    console.log("iniciando query de todas as categorias.");

    return new Promise((resolve, reject) => {
        db.transaction(
        tx => {
            tx.executeSql("select * from CATEGORIA", [], (_, { rows }) => {
                var categorias = [];

                for (let i = 0; i < rows.length; i++) {
                    let categoria = {
                        id: Number(rows.item(i).categoriaId),
                        nome: rows.item(i).descricao.toString()
                    };

                    categorias.push(categoria);
                }

                console.log("query de todas as categorias foi realizada! Qtde. categorias: " + categorias.length);
                resolve(categorias);
            });
        },
        (error) => {
            console.log("erro ao selecionar todas as categorias: " + error);
            resolve([]);
        },
        () => {
            console.log("transação de recuperação das queries executada com sucesso :)");
        });
    });
}