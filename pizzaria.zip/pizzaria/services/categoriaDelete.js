import { dbConnection } from './db';

const db=dbConnection.getConnection();

export default function deleteCategoria(idCategoria) {
    console.log("iniciando exclusão de categoria.");

    return new Promise((resolve, reject) => {
        db.transaction(
        tx => {
            tx.executeSql("delete from CATEGORIA where categoriaId=?;", [idCategoria], (_, { rowsAffected }) => {
                console.log("categoria excluida");
            });
            
            resolve(true);
        },
        (error) => {
            console.log("erro ao excluir a categoria: " + error);
            resolve(false);
        },
        () => {
            console.log("transação de exclusão de categoria realizada com sucesso :)");
        });
    });
}