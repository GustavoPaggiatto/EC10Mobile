import { dbConnection } from './db';

export function createDatabase() {
    console.log("Iniciando a criação do banco.");

    const command = 
       'CREATE TABLE IF NOT EXISTS CATEGORIA(categoriaId integer primary key AUTOINCREMENT, descricao text not null);' +
       'CREATE TABLE IF NOT EXISTS PRODUTO(produtoId integer primary key AUTOINCREMENT, nome text not null, preco real not null, categoriaId integer not null, FOREIGN KEY(categoriaId) REFERENCES CATEGORIA(categoriaId));' +
       'CREATE TABLE IF NOT EXISTS VENDA(vendaId integer primary key AUTOINCREMENT, data text not null);' +
       'CREATE TABLE IF NOT EXISTS VENDAPRODUTO(vendaProdutoId integer primary key AUTOINCREMENT, vendaId integer not null, produtoId integer not null, quantidade integer not null, FOREIGN KEY(vendaId) REFERENCES VENDA(vendaId), FOREIGN KEY(produtoId) REFERENCES PRODUTO(produtoId));';

    let connection = dbConnection.getConnection();
        
    connection.transaction(
        tx => {
            tx.executeSql(command);
            console.log("banco foi criado!");
        },
        (error) => {
            console.log("erro ao criar o banco: " + error);
        },
        () => {
            console.log("transação de criação do banco completa :)");
        }
    );
}