import { dbConnection } from './db';

const db=dbConnection.getConnection();

export default function addCategoria(nomeCategoria) {
    console.log("iniciando inserção de categoria.");

    return new Promise((resolve, reject) => {
        db.transaction(
        tx => {
            tx.executeSql("insert into CATEGORIA (descricao) values(?);", [nomeCategoria], (_, { insertId }) => {
                console.log("id nova categoria inserted: " + insertId);
            });
            
            resolve(true);
        },
        (error) => {
            console.log("erro ao inserir nova categoria: " + error);
            resolve(false);
        },
        () => {
            console.log("transação de criaçãode categoria realizada com sucesso :)");
        });
    });
}