import { dbConnection } from './db';

const db=dbConnection.getConnection();

export default function updateCategoria(idCategoria, nomeCategoria) {
    console.log("iniciando update de categoria.");

    return new Promise((resolve, reject) => {
        db.transaction(
        tx => {
            tx.executeSql("update CATEGORIA set descricao=? where categoriaId=?;", [nomeCategoria, idCategoria], (_, { rowsAffected }) => {
                console.log("categoria alterada");
            });
            
            resolve(true);
        },
        (error) => {
            console.log("erro ao alterar a categoria: " + error);
            resolve(false);
        },
        () => {
            console.log("transação de alteração de categoria realizada com sucesso :)");
        });
    });
}