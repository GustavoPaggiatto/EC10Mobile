import { Button, Divider, ListItem, Flex, IconButton, Dialog, DialogContent, TextInput, DialogActions, DialogHeader, Provider, Text } from '@react-native-material/core';
import Icon from "@expo/vector-icons/MaterialCommunityIcons";
import { useEffect, useState } from 'react';
import { Alert } from 'react-native';
import GetCategorias from './services/categoriasQuery';
import addCategoria from './services/novaCategoriaInsert';
import deleteCategoria from './services/categoriaDelete';
import updateCategoria from './services/categoriaUpdate';


export default function CategoriaComponent() {
    const [categorias, setCategorias] = useState([]);
    const [showAddCategoria, setShowAddCategoria] = useState(false);
    const [showDeleteCategoria, setShowDeleteCategoria] = useState(false);
    const [showEditCategoria, setShowEditCategoria] = useState(false);
    const [categoriaId, setCategoriaId] = useState(0);
    const [nome, setNome] = useState(""); 

    useEffect(() => {
        GetCategorias()
        .then((response) => {
            setCategorias(response);
        });
    },[]);    
    
    function adicionarCategoria() {
        if (nome === "") {
            Alert.alert("Nome não informado.");
            return;
        }

        addCategoria(nome.toString())
        .then((response) => {
            Alert.alert("Categoria criada com sucesso :)");
        
            setNome("");
            setShowAddCategoria(false);

            GetCategorias()
            .then((response) => {
                console.log("response.length => " + response.length);
                setCategorias(response);
            });
        },
        (error) => {
            Alert.alert("Ocorreu um erro ao inserir a categoria, tente novamente.");
        });
    }

    function prepareDeleteCategoria(id) {
        setCategoriaId(id);
        setShowDeleteCategoria(true);
    }

    function delCategoria() {
        deleteCategoria(categoriaId)
        .then((resolve) => {
            setCategoriaId(0);
            setShowDeleteCategoria(false);
            GetCategorias()
            .then((response) => {
                setCategorias(response);
            });

            Alert.alert("Categoria removida com sucesso :)");
        },
        (error) => {
            Alert.alert("Ocorreu um erro ao excluir a categoria, tente novamente.");
        });
    }

    function prepareUpdateCategoria(categoria) {
        setCategoriaId(categoria.id);
        setNome(categoria.nome);
        setShowEditCategoria(true);
    }

    function editCategoria() {
        if (nome === "") {
            Alert.alert("Nome não informado.");
            return;
        }

        updateCategoria(categoriaId, nome)
        .then((resolve) => {
            setCategoriaId(0);
            setNome("");
            setShowEditCategoria(false);
            GetCategorias()
            .then((response) => {
                setCategorias(response);
            });

            Alert.alert("Categoria alterada com sucesso :)");
        },
        (error) => {
            Alert.alert("Ocorreu um erro ao alterar a categoria, tente novamente.");
        });
    }

    return (
        <Provider>
            <Flex justify="start" items="center" spacing={10}>                
                <Button 
                title="Nova Categoria" 
                style={{width: 200, marginTop: 10}}
                onPress={() => setShowAddCategoria(true)} />
                <Divider style={{marginTop: 20}} />                
            </Flex> 
            {
                categorias.map((value, ix, never) => {   
                    return (
                        <Flex>
                            <ListItem 
                                title={value.nome} 
                                key={value.id}
                                trailing={props => 
                                    <Flex direction='row' key={"f_"+value.id}>
                                        <IconButton 
                                            key={"ibp_"+value.id} icon={props => <Icon name="pen" {...props} />} 
                                            style={{width: 25}}
                                            onPress={() => prepareUpdateCategoria(value)}/>
                                        <IconButton 
                                            key={"ibd_"+value.id}
                                            icon={props => <Icon name="delete" {...props} style={{color: "red"}}/>}
                                            onPress={() => prepareDeleteCategoria(value.id)}/>
                                    </Flex>
                                }/>     
                        </Flex>                        
                    );
                })
            }           
            <Dialog 
                visible={showAddCategoria}
                onDismiss={() => setShowAddCategoria(false)}>
                <DialogHeader title="" />
                <DialogContent>
                    <TextInput label="Nome" onChangeText={(text) => setNome(text)} />
                </DialogContent>
                <DialogActions>
                    <Button
                        title="Cancelar"
                        compact
                        variant="text"
                        onPress={() => setShowAddCategoria(false)}/>
                    <Button 
                        title="Adicionar" 
                        compact
                        variant="text"
                        onPress={() => adicionarCategoria()}/>
                </DialogActions>
            </Dialog>
            <Dialog 
                visible={showDeleteCategoria}
                onDismiss={() => setShowDeleteCategoria(false)}>
                <DialogHeader title="Atenção" />
                <DialogContent>
                    <Text>Deseja realmente excluir a categoria?</Text>
                </DialogContent>
                <DialogActions>
                    <Button
                        title="Não"
                        compact
                        variant="text"
                        onPress={() => setShowDeleteCategoria(false)}/>
                    <Button 
                        title="Sim" 
                        compact
                        variant="text"
                        onPress={() => delCategoria()}/>
                </DialogActions>
            </Dialog>
            <Dialog 
                visible={showEditCategoria}
                onDismiss={() => setShowEditCategoria(false)}>
                <DialogHeader title="Edição" />
                <DialogContent>
                    <TextInput label="Nome" onChangeText={(text) => setNome(text)} value={nome} />
                </DialogContent>
                <DialogActions>
                    <Button
                        title="Não"
                        compact
                        variant="text"
                        onPress={() => setShowEditCategoria(false)}/>
                    <Button 
                        title="Sim" 
                        compact
                        variant="text"
                        onPress={() => editCategoria()}/>
                </DialogActions>
            </Dialog>
        </Provider>
    );
}